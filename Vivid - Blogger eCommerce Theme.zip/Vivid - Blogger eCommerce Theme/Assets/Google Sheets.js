function doPost(e) {
    try {
        if (!e || !e.postData || !e.postData.contents) {
            return ContentService.createTextOutput(JSON.stringify({
                status: 'error',
                message: 'No POST data received'
            })).setMimeType(ContentService.MimeType.JSON);
        }

        // FIXED: Handle text/plain (CORS bypass)
        let data;
        try {
            // Try parsing as JSON first (for backward compatibility)
            data = JSON.parse(e.postData.contents);
        } catch {
            // If it's plain text, parse as JSON from string
            data = JSON.parse(e.postData.contents);
        }

        console.log('Received data:', data);

        var sheetId = 'Your_Sheet_ID'; // 👈 your sheet ID
        var ss = SpreadsheetApp.openById(sheetId);
        var sheet = ss.getSheetByName('Your_Sheet_Name'); // 👈 your sheet Name

        if (!sheet) {
            throw new Error('Sheet "Your_Sheet_Name" not found'); // 👈 your sheet Name
        }

        // Use a separate property to track order counter
        var scriptProps = PropertiesService.getScriptProperties();
        var lastOrderNum = parseInt(scriptProps.getProperty("lastOrderNum") || "1000", 10);
        var nextOrderNumber = lastOrderNum + 1;
        var orderId = "ORD-" + nextOrderNumber;
        scriptProps.setProperty("lastOrderNum", nextOrderNumber);


        var timestamp = new Date().toLocaleString();
        // Loop through each product in cartItems
        for (var i = 0; i < data.cartItems.length; i++) {
            var item = data.cartItems[i];

            var row = [
                i === 0 ? timestamp : '----',         // Timestamp
                i === 0 ? orderId : '----',           // Order ID
                i === 0 ? (data.name || '') : '----', // Customer Name
                i === 0 ? (data.email || '') : '----',// Email (Google Sheets auto-detects email)
                // Recommended: apostrophe method
                i === 0 ? ("'" + (data.phone || '')) : '----',
                i === 0 ? (data.shippingAddress || '') : '----',
                i === 0 ? (data.billingAddress || '') : '----',
                item.title || '',
                item.variant || '',
                item.qty || 1,
                `Rs ${Number(item.price).toFixed(2)}`,    // Price with currency
                item.image ? '=IMAGE("' + item.image + '")' : '',
                i === 0 ? (data.paymentMethod || '') : '----',
                i === 0 ? (data.notes || '') : '----',
                i === 0 ? `Rs ${Number(data.subtotal).toFixed(2)}` : '----',
                i === 0 ? `Rs ${Number(data.shipping).toFixed(2)}` : '----',
                i === 0 ? `Rs ${Number(data.total).toFixed(2)}` : '----'
            ];

            sheet.appendRow(row);
        }


        console.log('Row appended:', row);

        return ContentService
            .createTextOutput(JSON.stringify({
                status: 'success',
                message: 'Order added to sheet',
                orderId: orderId // ✅ return generated orderId to your checkout.js
            }))
            .setMimeType(ContentService.MimeType.JSON);

    } catch (error) {
        console.error('Error in doPost:', error);
        return ContentService.createTextOutput(JSON.stringify({
            status: 'error',
            message: error.toString()
        })).setMimeType(ContentService.MimeType.JSON);
    }
}

// Test function (run this to verify)
function testAppendData() {
    var testData = {
        name: 'Customer Name',
        email: 'test@example.com',
        phone: '0123456789',
        shippingAddress: ' Name | Address | City , State  Zip Code | Country',
        billingAddress: 'Same as shipping address',
        cartItems: 'Test Product (Size: Medium) (Image: https://example.com/image.jpg) - Qty: 1 - Price: $50.00',
        paymentMethod: 'COD',
        notes: 'Test notes',
        subtotal: '$50.00',
        shipping: '$5.00',
        total: '$55.00'
    };

    var sheetId = 'Your_Sheet_ID'; // 👈 your sheet ID
    var ss = SpreadsheetApp.openById(sheetId);
    var sheet = ss.getSheetByName('Your_Sheet_Name'); // 👈 your sheet Name

    var lastRow = sheet.getLastRow();
    var nextOrderNumber = 1000 + lastRow;
    var orderId = "ORD-" + nextOrderNumber;

    var timestamp = new Date().toLocaleString();
    // Loop through each product in cartItems
    for (var i = 0; i < data.cartItems.length; i++) {
        var item = data.cartItems[i];

        var row = [
            i === 0 ? timestamp : '----',         // Timestamp
            i === 0 ? orderId : '----',           // Order ID
            i === 0 ? (data.name || '') : '----', // Customer Name
            i === 0 ? (data.email || '') : '----',// Email (Google Sheets auto-detects email)
            // Recommended: apostrophe method
            i === 0 ? ("'" + (data.phone || '')) : '----',
            i === 0 ? (data.shippingAddress || '') : '----',
            i === 0 ? (data.billingAddress || '') : '----',
            item.title || '',
            item.variant || '',
            item.qty || 1,
            `Rs ${Number(item.price).toFixed(2)}`,    // Price with currency
            item.image ? '=IMAGE("' + item.image + '")' : '',
            i === 0 ? (data.paymentMethod || '') : '----',
            i === 0 ? (data.notes || '') : '----',
            i === 0 ? `Rs ${Number(data.subtotal).toFixed(2)}` : '----',
            i === 0 ? `Rs ${Number(data.shipping).toFixed(2)}` : '----',
            i === 0 ? `Rs ${Number(data.total).toFixed(2)}` : '----'
        ];

        sheet.appendRow(row);
    }

    console.log('Test row appended:', row);
}
