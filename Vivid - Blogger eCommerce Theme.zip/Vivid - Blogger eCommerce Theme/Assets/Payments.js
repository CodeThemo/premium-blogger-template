//-----------------PAYMENT METHODS------------------------------------//

   function initializeNewPaymentMethods() {
      const paymentWidgets = document.querySelectorAll('#payment-settings .widget');

      paymentWidgets.forEach(widget => {
        const title = widget.querySelector('h2').textContent.trim();
        const links = widget.querySelectorAll('.widget-content ul li a');

        if (title === 'Paypal') {
          const paypalLink = links[0]?.getAttribute('href');
          if (paypalLink) {
            const paypalButton = document.getElementById('paypal-redirect-button');
            if (paypalButton) {
              paypalButton.setAttribute('data-paypal-link', paypalLink);
            }
          }
        } else if (title === 'EasyPaisa') {
          const form = document.getElementById('easypaisa-form');
          if (links.length >= 3 && form) {
            form.querySelector('.info-box:nth-of-type(1) p').textContent = links[0].getAttribute('href');
            form.querySelector('.info-box:nth-of-type(2) p').textContent = links[1].getAttribute('href');
            form.querySelector('.qr-code').src = links[2].getAttribute('href');
          }
        } else if (title === 'Bank Transfer') {
          const form = document.getElementById('bank-form');
          if (links.length >= 4 && form) {
            form.querySelector('.info-box:nth-of-type(1) p').textContent = links[0].getAttribute('href');
            form.querySelector('.info-box:nth-of-type(2) p').textContent = links[1].getAttribute('href');
            form.querySelector('.info-box:nth-of-type(3) p').textContent = links[2].getAttribute('href');
            form.querySelector('.info-box:nth-of-type(4) p').textContent = links[3].getAttribute('href');
          }
        } else if (title === 'UPI Transfer') {
          const upiDetailsContainer = document.getElementById('upi-options-container-template');
          if (upiDetailsContainer) {
            const upiOptionsContainer = document.createElement('div');
            upiOptionsContainer.className = 'upi-options-container';

            links.forEach(link => {
              const name = link.textContent.trim();
              const qrUrl = link.getAttribute('href');

              const optionDiv = document.createElement('div');
              optionDiv.className = 'upi-payment-option';
              optionDiv.innerHTML = `
                                <img src="${qrUrl}" alt="${name} UPI QR Code" class="qr-code">
                                <h3>${name}</h3>
                            `;
              upiOptionsContainer.appendChild(optionDiv);
            });
            upiDetailsContainer.appendChild(upiOptionsContainer);
          }
        }
      });
    }