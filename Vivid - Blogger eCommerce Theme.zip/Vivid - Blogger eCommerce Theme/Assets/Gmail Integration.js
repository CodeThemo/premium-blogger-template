function doPost(e) {
      try {
        if (!e || !e.postData || !e.postData.contents) {
          return ContentService.createTextOutput(JSON.stringify({
            status: 'error',
            message: 'No POST data received'
          })).setMimeType(ContentService.MimeType.JSON);
        }

        let data;
        try {
          data = JSON.parse(e.postData.contents);
        } catch (err) {
          throw new Error('Invalid JSON in POST body');
        }

        // 🧾 CONFIGURATION
        const sheetId = 'Your_Sheet_ID'; // 👈 your sheet ID
        const sheetName = 'Your_Sheet_Name'; // 👈 your sheet Name
        const adminEmail = 'admin@gmail.com'; // 👈 your admin / sender email
        const senderName = 'Store Name'; // 👈 your store / sender name
        // ----------------

        const ss = SpreadsheetApp.openById(sheetId);
        const sheet = ss.getSheetByName(sheetName);
        if (!sheet) throw new Error(`Sheet "${sheetName}" not found`);

        const scriptProps = PropertiesService.getScriptProperties();
        const lastOrderNum = parseInt(scriptProps.getProperty('lastOrderNum') || '1000', 10);
        const nextOrderNumber = lastOrderNum + 1;
        const orderId = `ORD-${nextOrderNumber}`;
        scriptProps.setProperty('lastOrderNum', nextOrderNumber);

        const timestamp = new Date().toLocaleString();
        const cartItems = Array.isArray(data.cartItems) ? data.cartItems : [data.cartItems];

        // Append to sheet
        for (let i = 0; i < cartItems.length; i++) {
          const item = cartItems[i] || {};
          const row = [
            i === 0 ? timestamp : '----',
            i === 0 ? orderId : '----',
            i === 0 ? (data.name || '') : '----',
            i === 0 ? (data.email || '') : '----',
            i === 0 ? ("'" + (data.phone || '')) : '----',
            i === 0 ? (data.shippingAddress || '') : '----',
            i === 0 ? (data.billingAddress || '') : '----',
            item.title || '',
            item.variant || '',
            item.qty || 1,
            `${data.currency} ${Number(item.price || 0).toFixed(2)}`,
            item.image ? `=IMAGE("${item.image}")` : '',
            i === 0 ? (data.paymentMethod || '') : '----',
            i === 0 ? (data.notes || '') : '----',
            i === 0 ? `${data.currency} ${Number(data.subtotal || 0).toFixed(2)}` : '----',
            i === 0 ? `${data.currency} ${Number(data.shipping || 0).toFixed(2)}` : '----',
            i === 0 ? `${data.currency} ${Number(data.total || 0).toFixed(2)}` : '----'
          ];
          sheet.appendRow(row);
        }

        // 🧠 Build product HTML
        const productRows = cartItems.map(p => `
      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="padding:20px 0;border-bottom:1px solid #e2e8f0;">
        <tr>
          <td width="80" style="padding-right:15px;">
            <img src="${p.image || 'https://via.placeholder.com/80'}" width="80" height="80" alt="${p.title || 'Product'}" style="border-radius:8px;object-fit:cover;display:block;border:0;outline:none;">
          </td>
          <td style="vertical-align:top;">
            <h4 style="margin:0 0 4px 0;font-size:16px;font-weight:600;color:#2d3748;line-height:1.3;">${p.title || '-'}</h4>
            <p style="margin:0 0 8px 0;font-size:14px;color:#718096;line-height:1.4;">Variant: ${p.variant || '-'}</p>
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:10px;">
              <tr>
                <td style="width:50%;vertical-align:middle;">
                  <table role="presentation" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                      <td style="padding-right:8px;">
                        <span style="display:inline-block;width:24px;height:24px;background-color:#667eea;border-radius:50%;text-align:center;color:white;font-size:12px;line-height:24px;">${p.qty || 1}</span>
                      </td>
                      <td style="color:#4a5568;font-size:14px;vertical-align:middle;">Qty</td>
                    </tr>
                  </table>
                </td>
                <td style="width:50%;text-align:right;">
                  <span style="color:#2d3748;font-weight:700;font-size:18px;">${data.currency} ${Number(p.price || 0).toFixed(2)}</span>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    `).join('');

        // 🧱 Email-safe HTML template with inline CSS, PNG icons, and footer outside main body
        const htmlBody = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation Email</title>
</head>
<body style="margin:0;padding:0;background-color:#f8f9fa;">
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color:#f8f9fa;padding:20px;">
      <tr>
        <td align="center">
          <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="600" style="max-width:600px;background-color:#ffffff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08); overflow: hidden;">
            <!-- Main Header -->
            <tr>
              <td style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:40px 30px;text-align:center;color:#ffffff;">
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                  <tr>
                    <td style="text-align:center;">
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
                        <tr>
                          <td style="padding-right:10px;">
                            <img src="https://cdn-icons-png.flaticon.com/512/1828/1828640.png" width="24" height="24" alt="Checkmark" style="display:block;">
                          </td>
                          <td>
                            <h1 style="margin:0;font-size:28px;font-weight:600;letter-spacing:-0.5px;color:#ffffff;">Order Received!</h1>
                          </td>
                        </tr>
                      </table>
                      <p style="margin:8px 0 0 0;font-size:16px;opacity:0.95;font-weight:300;color:#ffffff;">Thank you for your purchase</p>
                      <div style="margin-top:20px;padding:12px 24px;background-color:rgba(255,255,255,0.15);border-radius:25px;display:inline-block;font-size:14px;font-weight:500;">
                        Order #<span style="color:#ffd700;">${orderId}</span>
                      </div>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Order Content -->
            <tr>
              <td style="padding:40px 30px;">
                <!-- Customer Info -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color:#f8f9fa;padding:25px;border-radius:10px;border-left:4px solid #667eea;margin-bottom:30px;">
                  <tr>
                    <td>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                        <tr>
                          <td style="padding-right:10px;">
                            <img src="https://cdn-icons-png.flaticon.com/512/1077/1077012.png" width="18" height="18" alt="User" style="display:block;">
                          </td>
                          <td>
                            <h2 style="margin:0;color:#2d3748;font-size:20px;font-weight:600;">Customer Info</h2>
                          </td>
                        </tr>
                      </table>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:15px;">
                        <tr>
                          <td style="width:50%;padding-right:20px;color:#4a5568;font-weight:500;font-size:14px;">Full Name:</td>
                          <td style="width:50%;color:#2d3748;font-weight:600;font-size:14px;">${data.name || '-'}</td>
                        </tr>
                        <tr>
                          <td style="width:50%;padding-right:20px;color:#4a5568;font-weight:500;font-size:14px;padding-top:8px;">Email:</td>
                          <td style="width:50%;color:#2d3748;font-weight:600;font-size:14px;padding-top:8px;">${data.email || '-'}</td>
                        </tr>
                        <tr>
                          <td style="width:50%;padding-right:20px;color:#4a5568;font-weight:500;font-size:14px;padding-top:8px;">Phone:</td>
                          <td style="width:50%;color:#2d3748;font-weight:600;font-size:14px;padding-top:8px;">${data.phone || '-'}</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <!-- Billing Address -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color:#f8f9fa;padding:25px;border-radius:10px;border-left:4px solid #667eea;margin-bottom:30px;">
                  <tr>
                    <td>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                        <tr>
                          <td style="padding-right:10px;">
                            <img src="https://cdn-icons-png.flaticon.com/512/1611/1611277.png" width="18" height="18" alt="Invoice" style="display:block;">
                          </td>
                          <td>
                            <h2 style="margin:0;color:#2d3748;font-size:20px;font-weight:600;">Billing Address</h2>
                          </td>
                        </tr>
                      </table>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:15px;">
                        <tr>
                          <td style="color:#38a169;font-weight:600;font-size:14px;">${data.billingAddress || '-'}</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <!-- Shipping Address -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color:#f8f9fa;padding:25px;border-radius:10px;border-left:4px solid #667eea;margin-bottom:30px;">
                  <tr>
                    <td>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                        <tr>
                          <td style="padding-right:10px;">
                            <img src="https://cdn-icons-png.flaticon.com/512/2928/2928892.png" width="18" height="18" alt="Shipping" style="display:block;">
                          </td>
                          <td>
                            <h2 style="margin:0;color:#2d3748;font-size:20px;font-weight:600;">Shipping Address</h2>
                          </td>
                        </tr>
                      </table>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:15px;">
                        <tr>
                          <td style="color:#38a169;font-weight:600;font-size:14px;">${data.shippingAddress || '-'}</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <!-- Order Summary -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color:#f8f9fa;padding:25px;border-radius:10px;border-left:4px solid #667eea;margin-bottom:30px;">
                  <tr>
                    <td>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                        <tr>
                          <td style="padding-right:10px;">
                            <img src="https://cdn-icons-png.flaticon.com/512/9752/9752284.png" width="18" height="18" alt="Cart" style="display:block;">
                          </td>
                          <td>
                            <h2 style="margin:0;color:#2d3748;font-size:20px;font-weight:600;">Order Summary</h2>
                          </td>
                        </tr>
                      </table>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:15px;">
                        <tr>
                          <td style="width:50%;padding-right:20px;color:#4a5568;font-weight:500;font-size:14px;">Order Date:</td>
                          <td style="width:50%;color:#2d3748;font-weight:600;font-size:14px;">${timestamp}</td>
                        </tr>
                        <tr>
                          <td style="width:50%;padding-right:20px;color:#4a5568;font-weight:500;font-size:14px;padding-top:8px;">Order Id:</td>
                          <td style="width:50%;color:#2d3748;font-weight:600;font-size:14px;padding-top:8px;">${orderId}</td>
                        </tr>
                        <tr>
                          <td style="width:50%;padding-right:20px;color:#4a5568;font-weight:500;font-size:14px;padding-top:8px;">Payment Method:</td>
                          <td style="width:50%;color:#2d3748;font-weight:600;font-size:14px;padding-top:8px;">${data.paymentMethod || '-'}</td>
                        </tr>
                        <tr>
                          <td style="width:50%;padding-right:20px;color:#4a5568;font-weight:500;font-size:14px;padding-top:8px;">Estimated Delivery:</td>
                          <td style="width:50%;color:#38a169;font-weight:600;font-size:14px;padding-top:8px;">3-5 business days</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <!-- Items Table -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:30px;">
                  <tr>
                    <td>
                      <h3 style="margin:0 0 20px 0;color:#2d3748;font-size:18px;font-weight:600;border-bottom:2px solid #e2e8f0;padding-bottom:8px;">Order Items</h3>
                      ${productRows}
                    </td>
                  </tr>
                </table>

                <!-- Pricing Summary -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:30px;">
                  <tr>
                    <td style="padding:20px 25px;background-color:#ffffff;">
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                        <tr>
                          <td style="width:50%;color:#4a5568;font-size:15px;">Subtotal</td>
                          <td style="width:50%;text-align:right;color:#2d3748;font-size:15px;">${data.currency} ${Number(data.subtotal || 0).toFixed(2)}</td>
                        </tr>
                        <tr>
                          <td style="width:50%;color:#4a5568;font-size:15px;padding-top:8px;">Shipping</td>
                          <td style="width:50%;text-align:right;color:#38a169;font-size:15px;padding-top:8px;">${data.currency} ${Number(data.shipping || 0).toFixed(2)}</td>
                        </tr>
                        <tr>
                          <td style="width:50%;color:#4a5568;font-size:15px;padding-top:8px;">Total</td>
                          <td style="width:50%;text-align:right;color:#2d3748;font-size:15px;padding-top:8px;">${data.currency} ${Number(data.total || 0).toFixed(2)}</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:20px 25px;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#ffffff;border-radius:50px;">
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                        <tr>
                          <td style="width:50%;font-size:18px;font-weight:600;">Grand Total</td>
                          <td style="width:50%;text-align:right;font-size:24px;font-weight:700;color:#ffd700;">${data.currency} ${Number(data.total || 0).toFixed(2)}</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <!-- Next Steps -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:30px;border-radius:12px;color:#ffffff;margin-bottom:30px;">
                  <tr>
                    <td style="text-align:center;">
                      <h3 style="margin:0 0 15px 0;font-size:20px;font-weight:600;">What's Next?</h3>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:20px;">
                        <tr>
                          <td style="width:33.33%;text-align:center;padding:0 10px;">
                            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                              <tr>
                                <td style="width:50px;height:50px; border-radius:50%;margin:0 auto 10px;">
                                  <img src="https://cdn-icons-png.flaticon.com/512/10345/10345656.png" width="20" height="20" alt="Processing" style="display:block;margin:15px auto;">
                                </td>
                              </tr>
                              <tr>
                                <td style="font-size:13px;line-height:1.4;opacity:0.95;">Processing</td>
                              </tr>
                            </table>
                          </td>
                          <td style="width:33.33%;text-align:center;padding:0 10px;">
                            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                              <tr>
                                <td style="width:50px;height:50px; border-radius:50%;margin:0 auto 10px;">
                                  <img src="https://cdn-icons-png.flaticon.com/512/1670/1670865.png" width="20" height="20" alt="Shipping" style="display:block;margin:15px auto;">
                                </td>
                              </tr>
                              <tr>
                                <td style="font-size:13px;line-height:1.4;opacity:0.95;">Shipping</td>
                              </tr>
                            </table>
                          </td>
                          <td style="width:33.33%;text-align:center;padding:0 10px;">
                            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                              <tr>
                                <td style="width:50px;height:50px; border-radius:50%;margin:0 auto 10px;">
                                  <img src="https://cdn-icons-png.flaticon.com/512/10543/10543159.png" width="20" height="20" alt="Delivered" style="display:block;margin:15px auto;">
                                </td>
                              </tr>
                              <tr>
                                <td style="font-size:13px;line-height:1.4;opacity:0.95;">Delivered</td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <!-- CTA Buttons -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:30px;">
                  <tr>
                    <td style="text-align:center;">
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
                        <tr>
                          <td style="padding-right:15px;">
                            <a href="#" style="display:inline-block;text-decoration:none;padding:15px 40px;border-radius:50px;font-weight:600;font-size:16px;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#ffffff;box-shadow:0 4px 15px rgba(102,126,234,0.4);">Buy Now</a>
                          </td>
                          <td>
                            <a href="#" style="display:inline-block;text-decoration:none;padding:15px 40px;border-radius:50px;font-weight:600;font-size:16px;background:#ffffff;color:#667eea;border:2px solid #667eea;box-shadow:0 4px 15px rgba(0,0,0,0.1);">Download Free</a>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <!-- Vivid Premium -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);outline:2px solid #e2e8f0;outline-offset:5px;border-radius:100px;margin:10px;padding:5px;">
                  <tr>
                    <td style="padding-right:30px;">
                      <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjw7oE16Rny0Nbz2saT5DhULN8KmB4hGeBVSpWRZ2Zw2IiLGmPn823JyBzZhzqCdJyiq10-f5tw67PBb1WZpv6_JVwYFDECRmmDVUD0xj0lie2TAF2N8eO0xSeiMVMC3TnKppJJkK8HNsqCZjkjNv_lckP3LiXs71YgLn_asOuO-7-VzjlGzMH3R24PvaU7/s320/Vivid%20Favicon.png" alt="" style="border-radius:50px;height:120px;width:120px;display:block;">
                    </td>
                    <td>
                      <h1 style="color:#ffffff;font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;font-size:24px;margin:0;">Vivid Premium Version</h1>
                    </td>
                  </tr>
                </table>

                <!-- Support -->
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="padding:20px 0;text-align:center;">
                  <tr>
                    <td>
                      <p style="margin:0 0 15px 0;color:#4a5568;font-size:14px;">Need help? We're here for you</p>
                      <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
                        <tr>
                          <td style="padding-right:20px;">
                            <a href="mailto:support@yourstore.com" style="color:#667eea;text-decoration:none;font-weight:500;font-size:14px;">support@yourstore.com</a>
                          </td>
                          <td style="padding-right:20px;color:#4a5568;font-size:14px;">•</td>
                          <td>
                            <a href="tel:+15551234567" style="color:#667eea;text-decoration:none;font-weight:500;font-size:14px;">+1 (555) 123-4567</a>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style="background-color:#2d3748;padding:30px;text-align:center;color:#a0aec0;">
                <p style="margin:0 0 20px 0;font-size:14px;line-height:1.5;">Thank you for shopping with us! We're excited to serve you.</p>
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;">
                  <tr>
                    <td style="padding:0 10px;">
                      <a href="#" style="color:#a0aec0;text-decoration:none;font-size:14px;padding:8px 12px;border-radius:4px;">Privacy Policy</a>
                    </td>
                    <td style="padding:0 10px;">
                      <a href="#" style="color:#a0aec0;text-decoration:none;font-size:14px;padding:8px 12px;border-radius:4px;">Terms of Service</a>
                    </td>
                    <td style="padding:0 10px;">
                      <a href="#" style="color:#a0aec0;text-decoration:none;font-size:14px;padding:8px 12px;border-radius:4px;">Unsubscribe</a>
                    </td>
                  </tr>
                </table>
                <p style="margin:20px 0 0 0;font-size:12px;opacity:0.8;">© 2025 Vivid Theme. All rights reserved.</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
</body>
</html>
`;

        // ✉️ Send emails with custom sender name
        GmailApp.sendEmail(data.email, `Order Confirmation - ${orderId}`, "Your email client does not support HTML.", {
          htmlBody: htmlBody,
          name: senderName
        });
        GmailApp.sendEmail(adminEmail, `New Order Received - ${orderId}`, "Order notification.", {
          htmlBody: htmlBody,
          name: senderName
        });

        return ContentService.createTextOutput(JSON.stringify({
          status: 'success',
          message: 'Order added & emails sent',
          orderId
        })).setMimeType(ContentService.MimeType.JSON);

      } catch (err) {
        console.error('❌ Error in doPost:', err);
        return ContentService.createTextOutput(JSON.stringify({
          status: 'error',
          message: err.toString()
        })).setMimeType(ContentService.MimeType.JSON);
      }
    }