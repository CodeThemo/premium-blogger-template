   //---------------------------------------Checkout Page Original Script--------------------------------//



        // checkout.js - Complete Fixed Version (CORS + All Errors Resolved)
        let selectedPaymentMethod = null;
        let customerData = {};
        let currentTab = "contact-section";

        function generateUUID() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
                const r = (Math.random() * 16) | 0, v = c === "x" ? r : (r & 0x3) | 0x8;
                return v.toString(16);
            });
        }

        function generateOrderId() {
            const orders = JSON.parse(localStorage.getItem("bloggerStoreOrders") || "[]");
            const orderCount = orders.length + 1;
            return `ORD-${1000 + orderCount}`;
        }

        const checkoutCart = {
            getCart: function () {
                try {
                    const cart = localStorage.getItem("simpleCart");
                    if (!cart || cart === "[]") return [];
                    const parsedCart = JSON.parse(cart);
                    return Array.isArray(parsedCart)
                        ? parsedCart.map((item) => ({
                            id: item.id || "missing-id",
                            title: item.title || "Untitled Product",
                            image: item.image || "https://via.placeholder.com/80?text=No+Image",
                            currentPrice: item.currentPrice || "$0.00",
                            oldPrice: item.oldPrice || "",
                            variant: item.variant || {},
                            quantity: item.quantity || 1,
                            variantKey: item.variantKey || "",
                        }))
                        : [];
                } catch (e) {
                    console.error("Error loading cart:", e);
                    return [];
                }
            },

            getCurrency: function () {
                const cart = this.getCart();
                if (cart.length > 0) {
                    const price = cart[0].currentPrice || "$0.00";
                    const match = price.match(/(Rs|₹|₨|\$)/);
                    return match ? match[0] : "Rs";

                }
                return "$";
            },

            calculateTotals: function () {
                const cart = this.getCart();
                let subtotal = 0;
                cart.forEach((item) => {
                    const priceStr = item.currentPrice.replace(/[^0-9.-]/g, "");
                    const price = parseFloat(priceStr) || 0;
                    subtotal += price * item.quantity;
                });
                const shipping = this.calculateShipping(subtotal);
                const total = subtotal + shipping;
                return { subtotal, shipping, total };
            },

            calculateShipping: function (subtotal) {
                if (subtotal === 0) return 0;
                return subtotal > 50 ? 0 : 5.99;
            },

            updateOrderSummary: function () {
                const cart = this.getCart();
                const currency = this.getCurrency();
                const cartItemsContainer = document.getElementById("cart-items");
                if (!cartItemsContainer) return;
                const totals = this.calculateTotals();

                cartItemsContainer.innerHTML = "";
                if (cart.length === 0) {
                    cartItemsContainer.innerHTML = `<div class="empty-cart-message"><i class="bi bi-bag-x"></i><p>Your cart is empty</p></div>`;
                } else {
                    cart.forEach((item) => {
                        const price = parseFloat(item.currentPrice.replace(/[^0-9.-]/g, "")) || 0;
                        const itemTotal = price * item.quantity;
                        let variantText = "";
                        if (item.variant && typeof item.variant === "object" && Object.keys(item.variant).length > 0) {
                            variantText = Object.values(item.variant)
                                .filter((val) => val && val !== "undefined" && val !== "" && val !== null)
                                .join(" / ");
                        }
                        const itemElement = document.createElement("div");
                        itemElement.className = "cart-item";
                        itemElement.innerHTML = `
                    <img src="${item.image}" alt="${item.title}" loading="lazy" class="cart-item-image" onerror="this.src='https://via.placeholder.com/80?text=Image+Error';">
                    <div class="cart-item-details">
                        <h4 class="cart-item-title">${item.title}</h4>
                        ${variantText ? `<div class="cart-item-variant">${variantText}</div>` : ""}
                        <div class="cart-item-meta">
                            <span class="cart-item-quantity">Qty: ${item.quantity}</span>
                            <span class="cart-item-price">${item.currentPrice}</span>
                        </div>
                    </div>
                `;
                        cartItemsContainer.appendChild(itemElement);
                    });
                }

                const subtotalEl = document.getElementById("cart-subtotal");
                if (subtotalEl) subtotalEl.textContent = `${currency} ${totals.subtotal.toFixed(2)}`;
                const shippingEl = document.getElementById("cart-shipping");
                if (shippingEl) shippingEl.textContent = totals.shipping === 0 ? "Free" : `${currency} ${totals.shipping.toFixed(2)}`;
                const totalEl = document.getElementById("cart-total");
                if (totalEl) totalEl.textContent = `${currency} ${totals.total.toFixed(2)}`;
                const codEl = document.getElementById("cod-total");
                if (codEl) codEl.textContent = `${currency} ${totals.total.toFixed(2)}`;
            },

            getOrderDetailsHTML: function () {
                const cart = this.getCart();
                const currency = this.getCurrency();
                const totals = this.calculateTotals();
                if (cart.length === 0) return '<div class="empty-cart-message">Your cart is empty</div>';
                let itemsHTML = cart.map((item) => {
                    const price = parseFloat(item.currentPrice.replace(/[^0-9.-]/g, "")) || 0;
                    const itemTotal = price * item.quantity;
                    let variantText = "";
                    if (item.variant && typeof item.variant === "object" && Object.keys(item.variant).length > 0) {
                        variantText = Object.values(item.variant)
                            .filter((val) => val && val !== "undefined" && val !== "" && val !== null)
                            .join(" / ");
                    }
                    return `
                <div class="cart-item">
                    <img src="${item.image}" alt="${item.title}" loading="lazy" onerror="this.style.display='none';">
                    <div class="cart-item-details">
                        <h4>${item.title}</h4>
                        ${variantText ? `<div>${variantText}</div>` : ""}
                        <div><span>${item.quantity} × ${item.currentPrice}</span></div>
                    </div>
                </div>
            `;
                }).join("");
                return `
            <h3>Order Summary</h3>
            ${itemsHTML}
            <div class="order-totals">
                <div><h2> Your Order Details </h2></div>
                <div><h3>Subtotal</h3><span>${currency} <span style='margin-right: 10px;'></span> ${totals.subtotal.toFixed(2)}</span></div>
                <div><h3>Shipping</h3><span>${totals.shipping === 0 ? "Free" : `${currency} <span style='margin-right: 10px;'></span> ${totals.shipping.toFixed(2)}`}</span></div>
                <div><h3>Total</h3><span>${currency} <span style='margin-right: 10px;'></span> ${totals.total.toFixed(2)}</span></div>
            </div>
        `;
            },
        };

        function showTab(tabId) {
            const tabs = ["contact-section", "shipping-section", "selection", "details"];
            const steps = ["step-contact", "step-shipping", "step-selection", "step-details"];

            tabs.forEach((tab) => {
                const tabElement = document.getElementById(tab);
                if (tabElement) tabElement.classList.add("hidden");
            });

            steps.forEach((step) => {
                const stepElement = document.getElementById(step);
                if (stepElement) {
                    stepElement.classList.remove("active", "completed");
                    const targetStep = `step-${tabId.replace("-section", "")}`;
                    if (steps.includes(targetStep)) {
                        if (step === targetStep) {
                            stepElement.classList.add("active");
                        } else if (steps.indexOf(step) < steps.indexOf(targetStep)) {
                            stepElement.classList.add("completed");
                        }
                    }
                }
            });

            const targetTab = document.getElementById(tabId);
            if (targetTab) {
                targetTab.classList.remove("hidden");
                currentTab = tabId;
            }

            if (tabId === "details" && selectedPaymentMethod) loadDetailsTab();
        }

        function validateEmail(email) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        }

        function validateContact() {
            const email = document.getElementById("email")?.value.trim() || "";
            const emailError = document.getElementById("email-error");
            let isValid = true;

            if (!validateEmail(email)) {
                if (emailError) emailError.classList.remove("hidden");
                const emailInput = document.getElementById("email");
                if (emailInput) emailInput.classList.add("input-error");
                isValid = false;
            } else {
                if (emailError) emailError.classList.add("hidden");
                const emailInput = document.getElementById("email");
                if (emailInput) emailInput.classList.remove("input-error");
            }
            return isValid;
        }

        function validateShipping() {
            const fields = ["name", "address", "city", "state", "country", "zip"];
            let isValid = true;

            fields.forEach((field) => {
                const input = document.getElementById(field);
                if (!input) return;
                const error = document.getElementById(`${field}-error`);
                const value = input.value.trim();

                if (!value) {
                    if (error) error.classList.remove("hidden");
                    input.classList.add("input-error");
                    isValid = false;
                } else {
                    if (error) error.classList.add("hidden");
                    input.classList.remove("input-error");
                }
            });

            if (!document.getElementById("same-as-shipping")?.checked) {
                const billingFields = [
                    "checkout-billing-name", "checkout-billing-address", "checkout-billing-city",
                    "checkout-billing-state", "checkout-billing-country", "checkout-billing-zip"
                ];
                billingFields.forEach((field) => {
                    const input = document.getElementById(field);
                    if (!input) return;
                    const error = document.getElementById(`${field}-error`);
                    const value = input.value.trim();

                    if (!value) {
                        if (error) error.classList.remove("hidden");
                        input.classList.add("input-error");
                        isValid = false;
                    } else {
                        if (error) error.classList.add("hidden");
                        input.classList.remove("input-error");
                    }
                });
            }

            return isValid;
        }

        function selectMethod(method) {
            selectedPaymentMethod = method;
            document.querySelectorAll(".payment-option").forEach((option) => option.classList.remove("selected"));
            const selectedOption = document.querySelector(`.payment-option[onclick="selectMethod('${method}')"]`);
            if (selectedOption) selectedOption.classList.add("selected");

            const nextButton = document.getElementById("next-button");
            if (nextButton) nextButton.classList.remove("hidden");
        }

function loadDetailsTab() {
  const formContent = document.getElementById("form-content");
  const paymentIcon = document.getElementById("payment-icon");
  if (!formContent) return;

  // --- Refresh customerData from form fields (so confirm uses the latest values) ---
  customerData = {
    email: document.getElementById("email")?.value.trim() || "",
    phone: document.getElementById("phone")?.value.trim() || "",
    notes: document.getElementById("notes")?.value.trim() || "",
    paymentMethod: selectedPaymentMethod,
    shippingAddress: {
      name: document.getElementById("name")?.value.trim() || "Not provided",
      address: document.getElementById("address")?.value.trim() || "Not provided",
      city: document.getElementById("city")?.value.trim() || "Not provided",
      state: document.getElementById("state")?.value.trim() || "Not provided",
      country: document.getElementById("country")?.value.trim() || "Not provided",
      zip: document.getElementById("zip")?.value.trim() || "Not provided",
    },
  };

  if (document.getElementById("same-as-shipping")?.checked) {
    customerData.billingAddress = { ...customerData.shippingAddress };
  } else {
    customerData.billingAddress = {
      name: document.getElementById("checkout-billing-name")?.value.trim() || "Not provided",
      address: document.getElementById("checkout-billing-address")?.value.trim() || "Not provided",
      city: document.getElementById("checkout-billing-city")?.value.trim() || "Not provided",
      state: document.getElementById("checkout-billing-state")?.value.trim() || "Not provided",
      country: document.getElementById("checkout-billing-country")?.value.trim() || "Not provided",
      zip: document.getElementById("checkout-billing-zip")?.value.trim() || "Not provided",
    };
  }

  // --- Payment icon (optional) ---
  const iconMap = {
    cod: "https://img.icons8.com/color/48/000000/cash-in-hand.png",
    paypal: "https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png",
    easypaisa: "https://seeklogo.com/images/E/easypaisa-new-logo-412D450720-seeklogo.com.png",
    upi: "https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo-vector.svg",
    bank: "https://uxwing.com/wp-content/themes/uxwing/download/banking-finance/bank-transfer-icon.png",
  };
  if (paymentIcon) {
    paymentIcon.src = iconMap[selectedPaymentMethod] || "";
    paymentIcon.onerror = () => { paymentIcon.src = "https://via.placeholder.com/48?text=Pay"; };
  }

  // --- Inject the payment form template into #form-content ---
  const templateId = `${selectedPaymentMethod}-form`;
  const template = document.getElementById(templateId);
  const paymentFormContent = template ? template.innerHTML : "";
  formContent.innerHTML = `
    ${paymentFormContent}
    <div class="customer-details-section" style="display:none;">
      <h3 class="section-title">Customer Information</h3>
      <div class="detail-row"><strong>Name:</strong> ${customerData.shippingAddress.name}</div>
    </div>
  `;

  // --- Helper to refresh customerData (used before calling processPayment) ---
  function refreshCustomerDataFromFields() {
    customerData.email = document.getElementById("email")?.value.trim() || customerData.email || "";
    customerData.phone = document.getElementById("phone")?.value.trim() || customerData.phone || "";
    customerData.notes = document.getElementById("notes")?.value.trim() || customerData.notes || "";

    customerData.shippingAddress = {
      name: document.getElementById("name")?.value.trim() || "Not provided",
      address: document.getElementById("address")?.value.trim() || "Not provided",
      city: document.getElementById("city")?.value.trim() || "Not provided",
      state: document.getElementById("state")?.value.trim() || "Not provided",
      country: document.getElementById("country")?.value.trim() || "Not provided",
      zip: document.getElementById("zip")?.value.trim() || "Not provided",
    };

    if (document.getElementById("same-as-shipping")?.checked) {
      customerData.billingAddress = { ...customerData.shippingAddress };
    } else {
      customerData.billingAddress = {
        name: document.getElementById("checkout-billing-name")?.value.trim() || "Not provided",
        address: document.getElementById("checkout-billing-address")?.value.trim() || "Not provided",
        city: document.getElementById("checkout-billing-city")?.value.trim() || "Not provided",
        state: document.getElementById("checkout-billing-state")?.value.trim() || "Not provided",
        country: document.getElementById("checkout-billing-country")?.value.trim() || "Not provided",
        zip: document.getElementById("checkout-billing-zip")?.value.trim() || "Not provided",
      };
    }
  }

  // --- PAYPAL: bind redirect + confirm buttons ---
if (selectedPaymentMethod === "paypal") {
  const paypalButton = document.getElementById("paypal-redirect-button");
  const confirmBtn = document.getElementById("paypal-confirm-button");

  // 🔎 Find PayPal widget
  let paypalLink = null;
  const widgets = document.querySelectorAll('#payment-settings .widget');
  widgets.forEach(widget => {
    const title = widget.querySelector('h2')?.textContent.trim().toLowerCase();
    if (title === "paypal") {
      const links = widget.querySelectorAll("a");

      // First <a> = Active flag
      const active = links[0]?.getAttribute("href") === "true";
      if (active && links.length > 1) {
        paypalLink = links[1].getAttribute("href"); // ✅ actual PayPal.me link
      }
    }
  });

  if (paypalButton) {
    paypalButton.onclick = function (e) {
      e.preventDefault();
      if (paypalLink) {
        window.open(paypalLink, "_blank", "noopener,noreferrer");
      } else {
        alert("PayPal is not active or link is missing.");
      }
    };
  }

  if (confirmBtn) {
    confirmBtn.onclick = function (e) {
      e.preventDefault();
      refreshCustomerDataFromFields();
      if (paypalLink) {
        processPayment("PayPal", e);
      } else {
        alert("PayPal is not active, cannot confirm order.");
      }
    };
  }
}


  // --- BANK / EASYPaisa / UPI confirm buttons (same pattern) ---
  if (selectedPaymentMethod === "bank") {
    const bankConfirmBtn = document.getElementById("bank-confirm-button");
    if (bankConfirmBtn) {
      bankConfirmBtn.onclick = function (e) {
        e.preventDefault();
        refreshCustomerDataFromFields();
        processPayment("Bank Transfer", e);
      };
    }
  }

  if (selectedPaymentMethod === "easypaisa") {
    const easypaisaConfirmBtn = document.getElementById("easypaisa-confirm-button");
    if (easypaisaConfirmBtn) {
      easypaisaConfirmBtn.onclick = function (e) {
        e.preventDefault();
        refreshCustomerDataFromFields();
        processPayment("EasyPaisa", e);
      };
    }
  }

  if (selectedPaymentMethod === "upi") {
    const upiConfirmBtn = document.getElementById("upi-confirm-button");
    if (upiConfirmBtn) {
      upiConfirmBtn.onclick = function (e) {
        e.preventDefault();
        refreshCustomerDataFromFields();
        processPayment("UPI Transfer", e);
      };
    }
  }
}



        function processPayment(methodName, event) {
            // FIXED: Prevent form submission and propagation
            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }

            const formSection = document.querySelector(".form-section");
            if (!formSection) return;

            const totals = checkoutCart.calculateTotals();
            const cart = checkoutCart.getCart();
            const currency = checkoutCart.getCurrency();

            const orderData = {
                email: customerData.email,
                phone: customerData.phone,
                shippingAddress: customerData.shippingAddress,
                billingAddress: customerData.billingAddress,
                notes: customerData.notes,
                paymentMethod: methodName,
                items: cart,
                subtotal: totals.subtotal,
                shipping: totals.shipping,
                total: totals.total,
                date: new Date().toISOString(),
                status: "Pending",
            };



            let orders = JSON.parse(localStorage.getItem("bloggerStoreOrders") || "[]");
            orders.push(orderData);
            localStorage.setItem("bloggerStoreOrders", JSON.stringify(orders));

            const formatAddressForSheets = (addr) => {
                const parts = [
                    addr.name,
                    addr.address,
                    `${addr.city}, ${addr.state} ${addr.zip}`,
                    addr.country
                ].filter(part => part && part.trim() !== "Not provided" && part.trim() !== "");
                return parts.join(" \n ") || "Address not provided";
            };

            const shippingAddrStr = formatAddressForSheets(customerData.shippingAddress);
            let billingAddrStr;
            const isSameAddress = JSON.stringify(customerData.shippingAddress) === JSON.stringify(customerData.billingAddress);
            if (isSameAddress) {
                billingAddrStr = "Same as shipping address";
            } else {
                billingAddrStr = formatAddressForSheets(customerData.billingAddress);
            }

            const formatCartItemForSheets = (item) => {
                const priceNum = parseFloat(item.currentPrice.replace(/[^0-9.-]/g, "")) || 0;
                let variantText = "";

                if (item.variant && typeof item.variant === "object" && Object.keys(item.variant).length > 0) {
                    const variantValues = Object.values(item.variant)
                        .filter(val => val && val !== "undefined" && val !== "" && val !== null);
                    if (variantValues.length > 0) {
                        variantText = ` (Size: ${variantValues.join(", ")})`;
                    }
                }

                const imageText = item.image && item.image !== "https://via.placeholder.com/80?text=No+Image"
                    ? `\n(Image: ${item.image})`
                    : "";

                // 👇 Added line breaks for readability + fixed Rs spacing
                return `${item.title}\n${variantText}${imageText}\nQty: ${item.quantity}\nPrice: Rs ${priceNum.toFixed(2)}`;
            };


            // Build structured cart items (not raw text)
            const structuredCartItems = cart.map(item => {
                const priceNum = parseFloat(item.currentPrice.replace(/[^0-9.-]/g, "")) || 0;

                let variantText = "";
                if (item.variant && typeof item.variant === "object" && Object.keys(item.variant).length > 0) {
                    variantText = Object.values(item.variant)
                        .filter(val => val && val !== "undefined" && val !== "" && val !== null)
                        .join(" / ");
                }

                return {
                    title: item.title,
                    variant: variantText || "Default",
                    image: item.image,
                    qty: item.quantity,
                    price: priceNum
                };
            });

            const sheetData = {
                name: customerData.shippingAddress.name || "Customer",
                email: orderData.email || "",
                phone: orderData.phone || "",
                shippingAddress: shippingAddrStr,
                billingAddress: billingAddrStr,
                cartItems: structuredCartItems,   // 👈 send array, not string
                paymentMethod: orderData.paymentMethod,
                notes: orderData.notes || "No notes",
                subtotal: orderData.subtotal,
                shipping: orderData.shipping,
                total: orderData.total
            };




            // FIXED: CORS Bypass - Use text/plain
            const sendToSheets = async () => {
                try {
            
            //----------------- Add Your App Script URL Here ----------------------//
            
                    const response = await fetch('Add_Your_App_Script_URL_Here', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'text/plain',  // FIXED: CORS bypass
                        },
                        body: JSON.stringify(sheetData)  // Send as string
                    });


                    if (response.ok) {
                        const resultText = await response.text();

                        let result;
                        try {
                            result = JSON.parse(resultText);
                        } catch (err) {
                            console.error("❌ Failed to place Order", err);
                            return;
                        }

                        console.log('✅ Google Sheets response:', result);

                        if (result.status === 'success') {
                            console.log('✅ Order successfully Placed');

                            // ✅ Use the real backend-generated orderId
                            orderData.orderId = result.orderId;

                            // Update confirmation message with correct orderId
                            const orderIdEl = document.getElementById("order-id-display");
                            if (orderIdEl) {
                                orderIdEl.textContent = `Your order #${orderData.orderId} has been received.`;
                            }

                        } else {
                            console.log('⚠️ Google Sheets warning:', result.message);
                        }
                    }
                    else {
                        console.log('⚠️ HTTP Error:', response.status);
                    }

                } catch (error) {
                    console.error('❌ Google Sheets error:', error);
                }
            };

            sendToSheets();

            // Confirmation UI
            const formatAddressForDisplay = (addr) => `${addr.name}\n${addr.address}\n${addr.city}, ${addr.state} ${addr.zip}\n${addr.country}`;

            const shippingAddr = formatAddressForDisplay(customerData.shippingAddress);
            let billingAddr = isSameAddress ? "Same as shipping address" : formatAddressForDisplay(customerData.billingAddress);

            const orderSummaryHTML = checkoutCart.getOrderDetailsHTML();
            formSection.innerHTML = `
        <div class="order-confirmation">
            <div class="success-animation">
                <svg viewBox="0 0 100 100">
                    <path class="checkmark" fill="none" stroke-width="6" stroke-miterlimit="10" d="M25,52l20,20l40-40" />
                </svg>
                <h2>Order Confirmed!</h2>
            </div>
            <div class="confirmation-details">
                <p>Thank you, ${customerData.shippingAddress.name || "Customer"}!</p>
                <p id="order-id-display">
                  Your order is being generated <span class="loading-dots"></span>
                </p>
                <div class="confirmation-summaries-grid">
                    <div class="summary-section">${orderSummaryHTML}</div>
                    <div class="summary-section">
                        <h3>Customer & Payment Details</h3>
                        <h4>Payment Method</h4><p>${orderData.paymentMethod}</p>
                        <h4>Contact Information</h4>
                        <p><strong>Email:</strong> ${customerData.email}</p>
                        <p><strong>Phone:</strong> ${customerData.phone || "Not provided"}</p>
                        <h4>Shipping Address</h4><p class="address-details">${shippingAddr}</p>
                        <h4>Billing Address</h4><p class="address-details">${billingAddr}</p>
                    </div>
                </div>
                <a href="/p/shop.html" class="button primary-button" style="margin-top: 2rem;">Continue Shopping</a>
            </div>
        </div>
    `;

            localStorage.removeItem("simpleCart");
            const cartCount = document.querySelector(".cart-count");
            if (cartCount) cartCount.textContent = "0";
            checkoutCart.updateOrderSummary();
        }

        function validateAndProceedToDetails() {
            if (!selectedPaymentMethod) {
                alert("Please select a payment method.");
                return;
            }
            showTab("details");
        }

       //-----------------PAYMENT METHODS------------------------------------// 
function initializeNewPaymentMethods() {
  const paymentWidgets = document.querySelectorAll("#payment-settings .widget");

  paymentWidgets.forEach((widget) => {
    const title = widget.querySelector("h2").textContent.trim();
    const links = widget.querySelectorAll(".widget-content ul li a");

    // Check "Active" status
    let isActive = true;
    links.forEach((link) => {
      if (link.textContent.trim().toLowerCase() === "active") {
        if (link.getAttribute("href").toLowerCase() === "false") {
          isActive = false;
        }
      }
    });

    if (!isActive) {
      // Hide payment method option in selection
      const optionMap = {
        Paypal: "paypal",
        EasyPaisa: "easypaisa",
        "Bank Transfer": "bank",
        "UPI Transfer": "upi",
        "Cash on Delivery": "cod",
      };

      const methodKey = optionMap[title];
      if (methodKey) {
        const optionElement = document.querySelector(
          `.payment-option[onclick*="${methodKey}"]`
        );
        if (optionElement) optionElement.style.display = "none";
      }

      // Hide payment form template
      const formMap = {
        Paypal: "paypal-form",
        EasyPaisa: "easypaisa-form",
        "Bank Transfer": "bank-form",
        "UPI Transfer": "upi-form",
      };

      const formId = formMap[title];
      if (formId) {
        const formElement = document.getElementById(formId);
        if (formElement) formElement.style.display = "none";
      }
      return; // Skip processing this method
    }

    // Process active payment methods
if (title === 'Paypal') {
  const paypalLink = links[0]?.getAttribute('href');
  if (paypalLink) {
    const paypalButton = document.getElementById('paypal-redirect-button');
    if (paypalButton) {
      // Save PayPal link
      paypalButton.setAttribute('data-paypal-link', paypalLink);

      // ✅ Add click event
      paypalButton.onclick = function (e) {
        e.preventDefault();
        const link = paypalButton.getAttribute('data-paypal-link');
        if (link) {
          window.open(link, "_blank"); // open PayPal.me in new tab
        } else {
          alert("PayPal link is not set up yet.");
        }
      };
    }
  }
}

else if (title === "EasyPaisa") {
      const form = document.getElementById("easypaisa-form");
      if (form) {
        links.forEach((link) => {
          const label = link.textContent.trim().toLowerCase();
          if (label.includes("account name")) {
            form.querySelector(".info-box:nth-of-type(1) p").textContent =
              link.getAttribute("href");
          } else if (label.includes("account number")) {
            form.querySelector(".info-box:nth-of-type(2) p").textContent =
              link.getAttribute("href");
          } else if (label.includes("qr code")) {
            form.querySelector(".qr-code").src = link.getAttribute("href");
          }
        });
      }
    } else if (title === "Bank Transfer") {
      const form = document.getElementById("bank-form");
      if (form) {
        links.forEach((link) => {
          const label = link.textContent.trim().toLowerCase();
          if (label.includes("account name")) {
            form.querySelector(".info-box:nth-of-type(1) p").textContent =
              link.getAttribute("href");
          } else if (label.includes("account number")) {
            form.querySelector(".info-box:nth-of-type(2) p").textContent =
              link.getAttribute("href");
          } else if (label.includes("bank name")) {
            form.querySelector(".info-box:nth-of-type(3) p").textContent =
              link.getAttribute("href");
          } else if (label.includes("ifsc")) {
            form.querySelector(".info-box:nth-of-type(4) p").textContent =
              link.getAttribute("href");
          }
        });
      }
    } else if (title === "UPI Transfer") {
      const upiDetailsContainer = document.getElementById(
        "upi-options-container-template"
      );
      if (upiDetailsContainer) {
        const upiOptionsContainer = document.createElement("div");
        upiOptionsContainer.className = "upi-options-container";

        links.forEach((link) => {
          const label = link.textContent.trim().toLowerCase();
          if (label !== "active") {
            const name = link.textContent.trim();
            const qrUrl = link.getAttribute("href");

            const optionDiv = document.createElement("div");
            optionDiv.className = "upi-payment-option";
            optionDiv.innerHTML = `
              <img src="${qrUrl}" alt="${name} UPI QR Code" class="qr-code">
              <h3>${name}</h3>
            `;
            upiOptionsContainer.appendChild(optionDiv);
          }
        });
        upiDetailsContainer.appendChild(upiOptionsContainer);
      }
    }
  });
}


        // FIXED: Enhanced DOM Ready with Null Checks
        document.addEventListener("DOMContentLoaded", function () {
            // FIXED: Prevent all form submissions globally
            document.querySelectorAll('form').forEach(form => {
                form.addEventListener('submit', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Form submission prevented');
                });
            });

            checkoutCart.updateOrderSummary();
            initializeNewPaymentMethods();

            if (checkoutCart.getCart().length === 0) {
                const formSection = document.querySelector(".form-section");
                if (formSection) {
                    formSection.innerHTML = `
                <div class="empty-cart-message">
                    <i class="bi bi-bag-x"></i>
                    <p>Your cart is empty.</p>
                    <span>Please add items to your cart to proceed with checkout.</span>
                    <a href="/p/shop.html" class="button primary-button" style="margin-top: 1.5rem;">Return to Shop</a>
                </div>
            `;
                }
                const progressBar = document.querySelector(".progress-bar");
                if (progressBar) progressBar.style.display = "none";  // FIXED: Null check
                return;
            }

            showTab("contact-section");

            const sameAsShipping = document.getElementById("same-as-shipping");
            const billingSection = document.getElementById("checkout-billing-address-section");
            if (sameAsShipping && billingSection) {  // FIXED: Null check before .style
                sameAsShipping.addEventListener("change", function () {
                    billingSection.style.display = this.checked ? "none" : "grid";
                });
                billingSection.style.display = sameAsShipping.checked ? "none" : "grid";
            }

            // FIXED: Event listeners with prevention and null checks
            const contactNext = document.getElementById("contact-next");
            if (contactNext) {
                contactNext.addEventListener("click", function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (validateContact()) showTab("shipping-section");
                });
            }

            const shippingBack = document.getElementById("shipping-back");
            if (shippingBack) {
                shippingBack.addEventListener("click", function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    showTab("contact-section");
                });
            }

            const shippingNext = document.getElementById("shipping-next");
            if (shippingNext) {
                shippingNext.addEventListener("click", function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (validateShipping()) showTab("selection");
                });
            }

            const selectionBack = document.getElementById("selection-back");
            if (selectionBack) {
                selectionBack.addEventListener("click", function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    showTab("shipping-section");
                });
            }

            const nextButton = document.getElementById("next-button");
            if (nextButton) {
                nextButton.addEventListener("click", function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    validateAndProceedToDetails();
                });
            }

            // FIXED: Payment options prevention
            document.querySelectorAll('.payment-option').forEach(button => {
                button.addEventListener('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                });
            });

            document.querySelectorAll(".input-field").forEach((input) => {
                input.addEventListener("input", function () {
                    this.classList.toggle("filled", this.value.trim() !== "");
                });
                input.classList.toggle("filled", input.value.trim() !== "");
            });
        });

        document.addEventListener("click", function (e) {
            if (e.target.classList.contains("view-checkout")) {
                e.preventDefault();
                window.location.href = "/p/checkout.html";
            }
        });

        document.addEventListener("DOMContentLoaded", function () {
            const checkoutPage = document.getElementById("CheckoutPage");
            if (checkoutPage) {
                const isCheckoutPage = window.location.pathname.includes("/p/checkout.html");
                checkoutPage.style.display = isCheckoutPage ? "block" : "none";
            }
        });
