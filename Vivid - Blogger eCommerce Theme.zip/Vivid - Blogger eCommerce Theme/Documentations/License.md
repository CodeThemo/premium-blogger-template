VIVID THEME LICENSE AGREEMENT

=============================



**Copyright (c) 2025 Vivid Theme**



This license governs the use of the Vivid Theme ("Theme"). By using this Theme, you agree to the terms below.



1\. Permitted Uses

-----------------

\- You may use this Theme on an unlimited number of websites.

\- You may modify and customize the user interface (UI), design, layout, and content for personal or client projects.

\- You may integrate the Theme with third-party services, plugins, or APIs as needed for your websites.



2\. Restrictions

---------------

\- You may NOT sell, redistribute, or republish the Theme or its source code as-is or in modified form.

\- You may NOT use the source code for creating derivative products for resale.

\- You may NOT claim the Theme as your own or remove copyright notices.



3\. Ownership

------------

The Theme and all associated files remain the property of the original author/developer. Ownership of the Theme's intellectual property and source code remains with the author.



4\. Warranty Disclaimer

----------------------

The Theme is provided "as-is" without warranty of any kind. The author is not liable for any damages, losses, or issues arising from its use.



5\. Compliance

-------------

By using this Theme, you agree to comply with the terms of this license. Non-compliance may result in legal action.



6\. Support

----------

Support, updates, or additional services are provided at the discretion of the author and may be subject to separate terms.



----------------------------------------

For any questions regarding this license, please contact:

**Vivid Theme**

[vivid.theme.developers@gmail.com](mailto:vivid.theme.developers@gmail.com)



